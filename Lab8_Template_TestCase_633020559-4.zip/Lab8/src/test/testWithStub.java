package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testWithStub {
	
	@Test
	void testUniversalConverterDistance() {
		UniversalStub UstubD = new UniversalStub();
		double expectedResult = 15000;
		assertEquals(expectedResult, UstubD.convert(15, "Distance", "kilometer", "meter"));
	}

	@Test
	void testDistanceConverter() {
		DistanceStub Dstub = new DistanceStub();
		double expectedResult = 20000;
		assertEquals(expectedResult, Dstub.convert(20, "kilometer", "meter"));
	}
	
	@Test
	void testTemperatureConverter() {
		TemperatureStub Tstub = new TemperatureStub();
		double expectedResult = 303.15;
		assertEquals(expectedResult, Tstub.convert(30, "C", "K"));
	}
	
	@Test
	void testWeightConverter() {
		WeightStub Wstub = new WeightStub();
		double expectedResult = 10000;
		assertEquals(expectedResult, Wstub.convert(10, "kilogram", "gram"));
	}
	
	@Test
	void testDistanceConverterMultiplier() {
		DistanceStub Dstub = new DistanceStub();
		double expectedResult = 1000;
		assertEquals(expectedResult, Dstub.getMultiplier("kilometer", "meter"));
	}
	
	
	@Test
	void testWeightConverterMultiplier() {
		WeightStub Wstub = new WeightStub();
		double expectedResult = 1000;
		assertEquals(expectedResult, Wstub.getMultiplier("kilogram", "gram"));
	}

}
