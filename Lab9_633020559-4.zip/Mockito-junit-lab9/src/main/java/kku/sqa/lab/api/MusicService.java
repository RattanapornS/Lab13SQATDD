package kku.sqa.lab.api;

import java.util.List;

public interface MusicService {
    public List<String> getMusic(String name);
}
